$("#sticky-tab").stick_in_parent({
	sticky_class: 'is-stuck'
});